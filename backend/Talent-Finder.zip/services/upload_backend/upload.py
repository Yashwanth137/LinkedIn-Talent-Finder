import os
import uuid
import re
import json
import shutil
import zipfile
import tempfile
import psycopg2

from config import settings
from langchain.prompts import load_prompt
from langchain_groq import ChatGroq
from InstructorEmbedding import INSTRUCTOR
from qdrant_client import QdrantClient
from qdrant_client.models import PointStruct, VectorParams, Distance
from langchain_core.output_parsers import JsonOutputParser
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader

# === Global Upload Progress (for polling) ===
UPLOAD_PROGRESS = {
    "processed": 0,
    "total": 0,
    "done": False
}

# === CONFIG ===
PROMPT_FILE = "./prompt.json"
QDRANT_COLLECTION = "llm_qdrant_llm"
GROQ_API_KEYS = [settings.api1, settings.api2, settings.api3]

# === DB Setup ===
pg_conn = psycopg2.connect(settings.postgres_url)
pg_cursor = pg_conn.cursor()
pg_cursor.execute('''
CREATE TABLE IF NOT EXISTS resumes_llm (
    id SERIAL PRIMARY KEY,
    document_id TEXT UNIQUE,
    name TEXT,
    email TEXT,
    mobile_number TEXT,
    years_experience FLOAT,
    skills TEXT[],
    roles TEXT[],
    location TEXT
);''')
pg_conn.commit()

# === Qdrant Setup ===
qdrant = QdrantClient(host=settings.qdrant_host)
embedder = INSTRUCTOR("hkunlp/instructor-large")

if not qdrant.collection_exists(QDRANT_COLLECTION):
    qdrant.create_collection(
        collection_name=QDRANT_COLLECTION,
        vectors_config=VectorParams(
            size=settings.embedding_dim,
            distance=Distance.COSINE
        )
    )

# === Prompt & LLM Setup ===
prompt = load_prompt(PROMPT_FILE)
parser = JsonOutputParser()

def create_llm(api_key):
    return ChatGroq(model='llama-3.3-70b-versatile', api_key=api_key)

def parse_resume(text):
    for key in GROQ_API_KEYS:
        try:
            llm = create_llm(key)
            chain = prompt | llm | parser
            return chain.invoke({"resume_text": text})
        except Exception as e:
            print(f"⚠️ LLM parsing failed with key {key[:10]}...: {e}")
            if "token" in str(e).lower():
                continue
    return {}

# === MAIN FUNCTION ===
def process_zip_file(zip_path: str):
    global UPLOAD_PROGRESS
    success, fail = [], []

    with tempfile.TemporaryDirectory() as temp_dir:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)

        files = [
            os.path.join(temp_dir, f)
            for f in os.listdir(temp_dir)
            if f.endswith(".pdf") or f.endswith(".docx")
        ]

        UPLOAD_PROGRESS = {
            "processed": 0,
            "total": len(files),
            "done": False
        }

        for i, file_path in enumerate(files):
            filename = os.path.basename(file_path)
            try:
                print(f"\n📄 Processing: {filename}")

                loader = PyPDFLoader(file_path) if filename.endswith(".pdf") else Docx2txtLoader(file_path)
                pages = loader.load()
                full_text = "\n".join(p.page_content for p in pages)
                full_text = re.sub(r'[\x00-\x1F\x7F]', '', full_text)
                doc_id = os.path.splitext(filename)[0]

                parsed = parse_resume(full_text)
                name = parsed.get("name")
                email = parsed.get("email")
                mobile_number = parsed.get("mobile_number")
                skills = parsed.get("skills") or []
                prev_roles = parsed.get("roles") or []
                years_experience = parsed.get("years_experience")
                location = parsed.get("location")

                pg_cursor.execute("""
                    INSERT INTO resumes_llm (
                        document_id, name, email, mobile_number,
                        years_experience, skills, prev_roles, location
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (document_id) DO NOTHING;
                """, (
                    doc_id, name, email, mobile_number,
                    years_experience, skills, prev_roles, location
                ))
                pg_conn.commit()

                embed_text = f"Skills: {', '.join(skills)}\nExperience: {years_experience} years\nRoles: {', '.join(roles)}"
                instruction = "Represent the resume for job relevance retrieval"
                vector = embedder.encode([[instruction, embed_text]])[0]

                qdrant.upsert(
                    collection_name=QDRANT_COLLECTION,
                    points=[PointStruct(
                        id=str(uuid.uuid4()),
                        vector=vector,
                        payload={
                            "document_id": doc_id,
                            "skills": skills,
                            "roles": roles,
                            "experience": years_experience
                        }
                    )]
                )

                print(f"✅ Stored & embedded: {doc_id}")
                success.append(filename)

            except Exception as e:
                print(f"❌ Failed to process {filename}: {e}")
                fail.append(filename)

            UPLOAD_PROGRESS["processed"] = i + 1

    UPLOAD_PROGRESS["done"] = True

    print("\n📊 Summary")
    print(f"✅ Success: {len(success)}")
    print(f"❌ Failed: {len(fail)}")

    return {
        "success": success,
        "failed": fail,
        "total": len(files)
    }

def get_upload_progress():
    return UPLOAD_PROGRESS
